import { Component, Input, OnInit, Output, EventEmitter } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
interface Book {
  title: string;
  imageUrl: string;
  purchaseLink: string;
  PublishDate: string;
}

interface Author {
  author: string;
  birthday: string;
  birthPlace: string;
  books: Book[];
}
@Component({
  selector: "books-table",
  templateUrl: "./books.component.html",
})
export class BooksComponent implements OnInit {
  sortOrder: any;
  @Input() booksData!: Author;
  displayStyle = "none";
  form: FormGroup;
  constructor(private fb: FormBuilder) {}

  ngOnInit() {
    this.form = this.fb.group({
      title: [""],
      imageUrl: [""],
      purchaseLink: [""],
      PublishDate: [""],
    });
  }

  sortBy = "title";

  sortedBooks(): Book[] {
    console.log(this.sortBy);
    return this.booksData.books.sort((a, b) => {
      if (this.sortBy === "title") {
        return a.title.localeCompare(b.title);
      } else if (this.sortBy === "PublishDate") {
        return a.PublishDate.localeCompare(b.PublishDate);
      }
    });
  }

  addBook(): void {
    const newBook: Book = {
      title: "New Book",
      imageUrl: "https://m.media-amazon.com/images/I/91oa7T-wJ+L.jpg",
      purchaseLink: "https://new-book-purchase-url.com",
      PublishDate: "May 1, 2020",
    };
    this.booksData.books.push(newBook);
  }

  deleteBook(book: Book): void {
    const index = this.booksData.books.indexOf(book);
    if (index >= 0) {
      this.booksData.books.splice(index, 1);
    }
  }

  updateBook(book: Book): void {
    //To do
  }

  openPopup() {
    this.displayStyle = "block";
  }
  closePopup() {
    this.displayStyle = "none";
  }

  onSubmitted() {
    // To do
  }
}
